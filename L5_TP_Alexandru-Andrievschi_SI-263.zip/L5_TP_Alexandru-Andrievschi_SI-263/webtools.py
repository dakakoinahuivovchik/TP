# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru
"""Modulul webtools: funcții reutilizabile pentru analiza unui site web."""

import csv
import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 47: constantă de modul, folosită în fetch()
DEFAULT_HEADERS = {"User-Agent": "WebLab-Andrievschi"}

SECURITY_HEADER_NAMES = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url cu GET și returnează obiectul răspuns."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Returnează textul dintre <title> și </title> (șir gol dacă lipsește)."""
    start = html.find("<title>")
    if start == -1:
        return ""
    start += len("<title>")
    end = html.find("</title>", start)
    if end == -1:
        return ""
    return html[start:end].strip()


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele 5 antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADER_NAMES}


def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează un șir ca '3/5'."""
    return f"{sum(results.values())}/{len(results)}"


def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu succes, altfel False (fără erori)."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list) -> dict:
    """Returnează {cale: cod_de_stare} pentru fiecare cale din listă."""
    results = {}
    for path in paths:
        results[path] = get_status(base + path)
        time.sleep(1)
    return results


def fetch_robots(base: str):
    """Returnează textul din /robots.txt sau None dacă fișierul lipsește."""
    try:
        response = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    if response.status_code != 200:
        return None
    return response.text


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow din textul robots.txt (acceptă None)."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate, în ordinea apariției."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


def split_links(links: list, domain: str, base: str = None) -> tuple:
    """Împarte legăturile în (interne, externe) față de domeniul dat."""
    base = base or "https://" + domain
    internal, external = [], []
    for link in links:
        full = urljoin(base, link)
        if urlparse(full).netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a conținutului paginii."""
    return hashlib.sha256(fetch(url).content).hexdigest()


def resolve(hostname: str) -> str:
    """Returnează adresa IP a unui nume de domeniu."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            not_after = tls.getpeercert()["notAfter"]
    expires = ssl.cert_time_to_seconds(not_after)
    return int((expires - time.time()) // 86400)


def redirect_chain(url: str) -> list:
    """Returnează lista 'cod -> url' pentru fiecare redirecționare, plus URL-ul final."""
    response = fetch(url)
    chain = [f"{r.status_code} -> {r.headers.get('Location', '?')}" for r in response.history]
    return chain or ["fără redirecționări (" + response.url + ")"]


def log(message: str, **details) -> None:
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [message] + [f"{key}={value}" for key, value in details.items()]
    print(" | ".join(parts))


def site_report(url: str) -> dict:
    """Colectează, afișează și salvează în report.json informațiile despre site."""
    parsed = urlparse(url)
    host = parsed.netloc

    response = fetch(url)
    time.sleep(1)
    title = get_title(response.text)
    ip = resolve(host)
    chain = redirect_chain("http://" + host)
    time.sleep(1)
    score = score_headers(security_headers(url))
    time.sleep(1)
    try:
        days = cert_days_left(host)
    except (OSError, ssl.SSLError):
        days = None
    internal, external = split_links(extract_links(response.text), host, url)
    time.sleep(1)
    disallowed = list(dict.fromkeys(disallowed_paths(fetch_robots(url))))  # fără duplicate

    report = {
        "url": url,
        "status": response.status_code,
        "final_url": response.url,
        "title": title,
        "ip": ip,
        "redirects": chain,
        "security_score": score,
        "cert_days_left": days,
        "internal_links": len(internal),
        "external_links": len(external),
        "disallowed": disallowed,
    }

    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare: {report['status']}")
    print(f"URL final: {report['final_url']}")
    print(f"Titlu: {title}")
    print(f"Adresă IP: {ip}")
    print(f"Redirecționări: {'; '.join(chain)}")
    print(f"Scor securitate: {score}")
    print(f"Certificat: {days} de zile rămase" if days is not None else "Certificat: indisponibil")
    print(f"Legături: {len(internal)} interne, {len(external)} externe")
    print(f"Căi interzise: {', '.join(disallowed) if disallowed else 'niciuna'}")

    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print("Salvat în report.json")
    return report


def save_csv(results: dict, filename: str = "report.csv") -> None:
    """Salvează {cale: status} în CSV cu coloanele path, status, checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
