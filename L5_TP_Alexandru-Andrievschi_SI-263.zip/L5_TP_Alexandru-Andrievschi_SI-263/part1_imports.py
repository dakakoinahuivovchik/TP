# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ---------- Exercițiul 1 ----------
import requests
import urllib.request

print("Ex.1 versiunea requests:", requests.__version__)
# requests este bibliotecă externă (terță parte): nu vine cu Python, deci trebuie
# descărcată de pe PyPI cu pip install. urllib face parte din biblioteca standard,
# care este instalată odată cu interpretorul Python.

# ---------- Exercițiul 2 ----------
import time

response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.2 (import requests) status:", response.status_code)
time.sleep(1)

from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Ex.2 (from requests import get) status:", response.status_code)
# Avantaj "import requests": se vede mereu de unde vine funcția (requests.get),
# nu apar conflicte de nume.
# Avantaj "from requests import get": cod mai scurt, fără prefix repetat.
time.sleep(1)

# ---------- Exercițiul 3 ----------
import requests as rq

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Ex.3 (alias rq) status:", response.status_code)
# Un alias ușurează citirea când numele e lung sau există o convenție unanimă
# (import numpy as np). Îl îngreunează când e criptic sau neuzual (rq, x, m),
# fiindcă cititorul trebuie să ghicească ce reprezintă.
time.sleep(1)

# ---------- Exercițiul 4 ----------
# Serverul respinge (403) antetul implicit "Python-urllib", de aceea trimitem un User-Agent propriu.
req = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-Andrievschi"})
with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
    print("Ex.4 status:", resp.status)
    body = resp.read().decode("utf-8")
    print("Ex.4 primele 200 caractere:", body[:200])
time.sleep(1)

# ---------- Exercițiul 5 ----------
print("Ex.5 dir(requests):", dir(requests))
# get      -> funcție (requests.get(url, ...))
# Session  -> clasă (requests.Session)
# exceptions -> modul (requests.exceptions, submodul al pachetului)

# ---------- Exercițiul 6 ----------
help(requests.get)
# Parametrul pentru timpul maxim de așteptare este timeout.
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.6 status cu timeout:", response.status_code)
time.sleep(1)

# ---------- Exercițiul 7 ----------
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
durata = time.perf_counter() - start
print(f"Ex.7 perf_counter: {durata:.3f} s")
print(f"Ex.7 response.elapsed: {response.elapsed.total_seconds():.3f} s")
# perf_counter include și crearea conexiunii/DNS și prelucrarea de către requests;
# response.elapsed măsoară de la trimiterea cererii până la sosirea antetelor,
# deci de obicei este puțin mai mic.

# ---------- Exercițiul 8 ----------
try:
    import bs4
    print("Ex.8 bs4 este instalat, versiunea", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificați-vă:
# - modul = un singur fișier .py care se poate importa;
# - pachet = director cu __init__.py care grupează mai multe module;
# - bibliotecă = termen general: colecție de module/pachete cu un scop (ex. requests).
