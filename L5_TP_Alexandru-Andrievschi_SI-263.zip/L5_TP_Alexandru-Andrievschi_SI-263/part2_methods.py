# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru
import time

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

response = requests.get(BASE_URL, timeout=TIMEOUT)
time.sleep(1)

# ---------- Exercițiul 9 ----------
print("Ex.9 status_code:", response.status_code)  # atribut
print("Ex.9 ok:", response.ok)                    # atribut (proprietate, fără paranteze)
print("Ex.9 url:", response.url)                  # atribut
print("Ex.9 encoding:", response.encoding)        # atribut

# ---------- Exercițiul 10 ----------
response.raise_for_status()  # metodă: nu face nimic dacă codul este 2xx
print("Ex.10 pagina principală: fără eroare")
time.sleep(1)
try:
    bad = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    bad.raise_for_status()
    print("Ex.10 pagina inexistentă a răspuns totuși cu", bad.status_code)
except requests.HTTPError as err:
    print("Ex.10 Pagina nu a fost găsită, dar programul continuă. Detalii:", err)
time.sleep(1)

# cybercor.org răspunde cu 200 și pentru pagini inexistente (rutare pe partea de client),
# deci HTTPError nu apare acolo. Pentru a demonstra prinderea excepției folosim httpbin,
# care returnează un 404 real (doar citire, către ECHO_URL este permis).
try:
    requests.get(ECHO_URL + "/status/404", timeout=TIMEOUT).raise_for_status()
except requests.HTTPError as err:
    print("Ex.10 (httpbin) Pagina nu a fost găsită, dar programul continuă. Detalii:", err)
time.sleep(1)

# ---------- Exercițiul 11 ----------
for name, value in response.headers.items():
    print(f"Ex.11 {name}: {value}")

# ---------- Exercițiul 12 ----------
print("Ex.12 Server:", response.headers.get("Server", "lipsește"))
print("Ex.12 Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("Ex.12 content-type (litere mici):", response.headers.get("content-type", "lipsește"))
# Observație: se obține aceeași valoare, deoarece response.headers este un
# dicționar insensibil la majuscule (CaseInsensitiveDict).

# ---------- Exercițiul 13 ----------
print("Ex.13 apariții 'cyber':", response.text.lower().count("cyber"))
# Se pot înlănțui deoarece .lower() returnează un șir nou (str), iar str are
# metoda .count(); rezultatul fiecărei metode este obiectul pe care îl apelează următoarea.

# ---------- Exercițiul 14 ----------
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print("Ex.14 titlu:", html[start:end].strip())

# ---------- Exercițiul 15 ----------
lines = html.splitlines()
print("Ex.15 număr de linii:", len(lines))
print("Ex.15 cea mai lungă linie:", len(max(lines, key=len)), "caractere")

# ---------- Exercițiul 16 ----------
if response.url.startswith("https://"):
    print("Ex.16 Conexiune securizată")
else:
    print("Ex.16 Conexiune nesecurizată")

# ---------- Exercițiul 17 ----------
r = requests.get("http://cybercor.org", timeout=TIMEOUT)
for hop in r.history:
    print("Ex.17 redirecționare:", hop.status_code, hop.url)
print("Ex.17 URL final:", r.url)
time.sleep(1)

# ---------- Exercițiul 18 ----------
h = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
g = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex.18 HEAD len(content):", len(h.content))
print("Ex.18 GET  len(content):", len(g.content))
# HEAD cere doar antetele, serverul nu trimite corpul, deci lungimea este 0;
# GET returnează și corpul (codul HTML), deci lungimea este mare.
time.sleep(1)

# ---------- Exercițiul 19 ----------
if len(response.cookies) == 0:
    print("Ex.19 Niciun cookie setat")
for cookie in response.cookies:
    print("Ex.19 cookie:", cookie.name, "secure =", cookie.secure)

# ---------- Exercițiul 20 ----------
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Andrievschi"})
echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Ex.20 răspuns httpbin:", echo.json())
print("Ex.20 antet confirmat:", echo.json()["headers"]["User-Agent"])

# Verificați-vă:
# response.text este un atribut (o valoare deja calculată: corpul ca șir de caractere),
# deci se citește fără paranteze. response.json() este o metodă: execută o acțiune
# (parsează corpul ca JSON și poate ridica eroare), deci se apelează cu paranteze.
