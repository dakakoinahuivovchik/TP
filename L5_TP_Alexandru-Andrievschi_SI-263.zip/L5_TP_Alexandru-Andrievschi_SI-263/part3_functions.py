# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru
import time

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# ---------- Exercițiile 21 și 23 ----------
def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarcă url cu GET și returnează obiectul răspuns (timeout implicit 10 s)."""
    return requests.get(url, timeout=timeout)


print("Ex.21 status:", fetch(BASE_URL).status_code)
time.sleep(1)
print("Ex.23 timeout implicit:", fetch(BASE_URL).status_code)
time.sleep(1)
print("Ex.23 timeout=3:", fetch(BASE_URL, timeout=3).status_code)
time.sleep(1)


# ---------- Exercițiul 22 ----------
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


for path in ["/", "/robots.txt", "/sitemap.xml"]:
    print("Ex.22", path, "->", get_status(BASE_URL + path))
    time.sleep(1)


# ---------- Exercițiile 24 și 25 ----------
def get_title(html: str) -> str:
    """Returneaza titlul paginii (textul dintre <title> si </title>).

    Functia nu foloseste reteaua: primeste un sir HTML deja descarcat.
    """
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    return html[start:end].strip()


print("Ex.24 titlu:", get_title(fetch(BASE_URL).text))
help(get_title)  # Ex.25
time.sleep(1)

# ---------- Exercițiul 26 ----------
# Adnotările (url: str) -> int sunt doar indicii pentru programatori și
# instrumente de analiză; Python NU le verifică la rulare.
try:
    print(get_status(123))
except Exception as err:
    print("Ex.26 get_status(123) a eșuat cu", type(err).__name__, ":", err)
# Eroarea vine din requests (URL invalid), nu din adnotare: adnotările nu ne opresc.


# ---------- Exercițiul 27 ----------
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde, False la orice eroare de rețea."""
    try:
        return fetch(url).ok
    except requests.RequestException:
        return False


print("Ex.27 site real:", page_exists(BASE_URL))
print("Ex.27 domeniu inexistent:", page_exists("https://this-domain-does-not-exist.invalid"))
time.sleep(1)


# ---------- Exercițiul 28 ----------
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare}."""
    results = {}
    for path in paths:
        results[path] = get_status(base + path)
        time.sleep(1)
    return results


print("Ex.28", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))


# ---------- Exercițiul 29 ----------
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name sau default dacă lipsește."""
    return fetch(url).headers.get(name, default)


print("Ex.29 Server:", get_header(BASE_URL, name="Server"))
time.sleep(1)

# ---------- Exercițiile 30 și 31 ----------
SECURITY_HEADER_NAMES = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]


def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele 5 antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADER_NAMES}


def score_headers(results: dict) -> str:
    """Returnează scorul sub forma 'prezente/total', de exemplu '3/5'."""
    return f"{sum(results.values())}/{len(results)}"


rezultat = security_headers(BASE_URL)
print("Ex.30", rezultat)
print("Ex.31 scor:", score_headers(rezultat))
time.sleep(1)


# ---------- Exercițiul 32 ----------
def fetch_robots(base: str):
    """Returnează textul din /robots.txt sau None dacă lipsește."""
    try:
        response = fetch(base + "/robots.txt")
    except requests.RequestException:
        return None
    return response.text if response.status_code == 200 else None


def disallowed_paths(robots_text) -> list:
    """Returnează lista valorilor Disallow; acceptă și None."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths


print("Ex.32 Disallow:", disallowed_paths(fetch_robots(BASE_URL)))
print("Ex.32 cu None:", disallowed_paths(None))
time.sleep(1)


# ---------- Exercițiul 33 ----------
def response_times(*urls: str) -> dict:
    """Returnează {url: secunde} pentru oricâte adrese."""
    times = {}
    for url in urls:
        start = time.perf_counter()
        fetch(url)
        times[url] = round(time.perf_counter() - start, 3)
        time.sleep(1)
    return times


print("Ex.33", response_times(BASE_URL, BASE_URL + "/robots.txt"))


# ---------- Exercițiul 34 ----------
def log(message: str, **details) -> None:
    """Afișează mesajul urmat de detalii, separate prin ' | '."""
    parts = [message] + [f"{k}={v}" for k, v in details.items()]
    print(" | ".join(parts))


log("verificat", url=BASE_URL, status=200)

# Verificați-vă:
# print() doar afișează valoarea pe ecran și funcția returnează None; valoarea nu
# poate fi folosită mai departe. return trimite valoarea apelantului, care o poate
# stoca, compara sau transmite altei funcții (ex. score_headers(security_headers(...))).
