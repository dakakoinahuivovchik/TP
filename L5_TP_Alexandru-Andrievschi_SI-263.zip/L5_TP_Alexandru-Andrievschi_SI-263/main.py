# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru
import argparse

import webtools
from webtools import DEFAULT_HEADERS, check_paths, get_title, save_csv, security_headers, site_report

# Exercițiul 45: dacă main.py ar avea propria funcție get_title, definiția
# locală ar suprascrie numele importat (se păstrează ultima atribuire a numelui),
# deci webtools.get_title nu ar mai putea fi apelată prin acest nume.
# Soluții: "import webtools" și apel webtools.get_title, sau alias (as).


def main():
    parser = argparse.ArgumentParser(description="Raport despre un site web")
    parser.add_argument("url", help="adresa site-ului, ex. https://cybercor.org")
    args = parser.parse_args()
    url = args.url.rstrip("/")

    # Ex. 44: apel prin prefixul modulului
    print("Titlu (webtools.get_title):", webtools.get_title(webtools.fetch(url).text))
    # Ex. 45: nume importate direct
    print("Titlu (get_title):", get_title(webtools.fetch(url).text))
    print("Antete de securitate:", security_headers(url))
    # Ex. 47: constanta importată
    print("DEFAULT_HEADERS:", DEFAULT_HEADERS)
    # Ex. 49: raport CSV
    save_csv(check_paths(url, ["/", "/robots.txt", "/sitemap.xml"]))
    print("Salvat în report.csv")
    # Ex. 50: raportul final
    site_report(url)


if __name__ == "__main__":
    main()
