# Laborator: funcții, metode și importuri pe web
# Student: Andrievschi Alexandru
import hashlib
import json
import re
import socket
import ssl
import time
import urllib.parse
from datetime import datetime
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ---------- Exercițiul 35 ----------
p = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
print("Ex.35", p.scheme, p.netloc, p.path, p.query, p.fragment)

# ---------- Exercițiul 36 ----------
for rel in ["/about", "contact.html", "../index.html"]:
    print("Ex.36", rel, "->", urljoin(BASE_URL, rel))


# ---------- Exercițiul 37 ----------
def extract_links(html: str) -> list:
    """Returnează legăturile href din html, fără duplicate, în ordinea apariției."""
    return list(dict.fromkeys(re.findall(r'href="([^"]+)"', html)))


response = requests.get(BASE_URL, timeout=TIMEOUT)
links = extract_links(response.text)
print("Ex.37 legături unice:", len(links))
time.sleep(1)


# ---------- Exercițiul 38 ----------
def split_links(links: list, domain: str) -> tuple:
    """Returnează (legături interne, legături externe) față de domain."""
    internal, external = [], []
    for link in links:
        full = urljoin("https://" + domain, link)
        if urlparse(full).netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external


interne, externe = split_links(links, "cybercor.org")
print("Ex.38", len(interne), "interne,", len(externe), "externe")


# ---------- Exercițiul 39 ----------
class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


test_html = """
<html><body>
<img src="/logo.png" alt="Logo">
<IMG SRC="poza.jpg">
<img alt="imagine fără src">
<img src="https://cdn.example.com/banner.webp" />
<a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
finder = ImageFinder()
finder.feed(test_html)
print(finder.images)
assert finder.images == [
    "/logo.png",                             # imagine obișnuită
    "poza.jpg",                              # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",   # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)
print("Verificare: <img apare de", response.text.lower().count("<img"), "ori")
time.sleep(1)


# ---------- Exercițiul 40 ----------
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a conținutului paginii."""
    return hashlib.sha256(requests.get(url, timeout=TIMEOUT).content).hexdigest()


a = page_fingerprint(BASE_URL)
time.sleep(1)
b = page_fingerprint(BASE_URL)
print("Ex.40", a)
print("Ex.40 identice:", a == b)
# Amprentele diferă dacă pagina s-a modificat între cereri (conținut dinamic:
# oră, token CSRF, anunțuri) sau dacă serverul întoarce versiuni diferite.
time.sleep(1)

# ---------- Exercițiul 41 ----------
response = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as file:
    json.dump(dict(response.headers), file, indent=2)
with open("headers.json", encoding="utf-8") as file:
    loaded = json.load(file)
print("Ex.41 Content-Type din fișier:", loaded.get("Content-Type"))


# ---------- Exercițiul 42 ----------
def resolve(hostname: str) -> str:
    """Returnează adresa IP a numelui de domeniu."""
    return socket.gethostbyname(hostname)


print("Ex.42 IP cybercor.org:", resolve("cybercor.org"))


# ---------- Exercițiul 43 ----------
def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls:
            not_after = tls.getpeercert()["notAfter"]
    expires = ssl.cert_time_to_seconds(not_after)
    return int((expires - datetime.now().timestamp()) // 86400)


print("Ex.43 zile rămase:", cert_days_left("cybercor.org"))

# Verificați-vă:
# handle_starttag() este apelată de HTMLParser, din interiorul metodei feed():
# parserul citește textul HTML și, la fiecare tag de deschidere întâlnit, apelează
# metoda noastră (principiul "nu ne sunați, vă sunăm noi" - callback).
